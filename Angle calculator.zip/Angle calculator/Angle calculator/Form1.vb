﻿Public Class frmAngleCalculator
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim angle As Integer
        angle = Int(txtAngle.Text)
        txtCos.Text = Math.Cos(angle)
        txtSin.Text = Math.Sin(angle)
        txtTan.Text = Math.Tan(angle)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtAngle.Clear()
        txtCos.Clear()
        txtSin.Clear()
        txtTan.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
